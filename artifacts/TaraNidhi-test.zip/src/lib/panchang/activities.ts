import { CATALOG } from "./catalog";
export type Tier = "daily" | "major";
export type Purushartha = "dharma" | "artha" | "kama" | "moksha";
export type Tatva = "agni" | "prithvi" | "vayu" | "jala";
export type Guna = "sattva" | "rajas" | "tamas";

export type Activity = {
  key: string;
  name: string;
  nameHi: string;
  category: string;
  preferredVara: string[];
  preferredNakshatra: string[];
  avoidTithi: number[];
  minTara: number;
  karaka: string[];
  blurb: string;
  tier: Tier;
  purushartha: Purushartha;
  tatva: Tatva;
  guna: Guna;
  creditCost: number;
};

type Seed = Omit<Activity, "tier" | "purushartha" | "tatva" | "guna" | "creditCost">;

const careerVara = ["Wednesday", "Thursday", "Friday"];
const financeVara = ["Thursday", "Friday", "Wednesday"];
const relVara = ["Monday", "Wednesday", "Thursday", "Friday"];
const avoidRikta = [4, 8, 9, 14, 30];
const avoidLight = [4, 9, 14];

export const CATEGORIES = [
  "Career",
  "Business",
  "Marketing",
  "Finance",
  "Health",
  "Travel",
  "Purchase",
  "Real Estate",
  "Relationship",
  "Family",
  "Education",
  "Legal",
  "Civic",
  "Media",
  "Technology",
  "Daily",
  "Spiritual",
] as const;

export const SEED: Seed[] = [
  { key: "job_interview", name: "Job interview", nameHi: "नौकरी का इंटरव्यू", category: "Career", preferredVara: careerVara, preferredNakshatra: ["Hasta", "Pushya", "Rohini", "Revati"], avoidTithi: avoidRikta, minTara: 2, karaka: ["Mercury", "Jupiter", "Sun"], blurb: "Mercury hora and Tara Sampat or Mitra favour first impressions." },
  { key: "job_joining", name: "First day / joining", nameHi: "जॉइनिंग", category: "Career", preferredVara: careerVara, preferredNakshatra: ["Rohini", "Uttara Phalguni", "Pushya"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Sun", "Jupiter"], blurb: "Fixed nakshatras support a lasting start." },
  { key: "promotion_talk", name: "Promotion discussion", nameHi: "प्रमोशन चर्चा", category: "Career", preferredVara: ["Thursday", "Wednesday"], preferredNakshatra: ["Pushya", "Uttara Phalguni", "Hasta"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Sun", "Jupiter"], blurb: "Jupiter weekday plus strong Chandra Bala." },
  { key: "resignation", name: "Resignation", nameHi: "इस्तीफा", category: "Career", preferredVara: ["Thursday", "Friday"], preferredNakshatra: ["Hasta", "Swati", "Anuradha"], avoidTithi: avoidRikta, minTara: 2, karaka: ["Saturn", "Sun"], blurb: "Avoid Vishti; keep Tara above Vipat." },
  { key: "performance_review", name: "Performance review", nameHi: "परफॉर्मेंस रिव्यू", category: "Career", preferredVara: careerVara, preferredNakshatra: ["Hasta", "Pushya"], avoidTithi: avoidLight, minTara: 2, karaka: ["Mercury", "Sun"], blurb: "Swift nakshatras keep the conversation clear." },
  { key: "salary_negotiation", name: "Salary negotiation", nameHi: "वेतन बातचीत", category: "Career", preferredVara: financeVara, preferredNakshatra: ["Pushya", "Rohini", "Hasta"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Jupiter", "Venus"], blurb: "Jupiter and Venus as karakas of gain." },
  { key: "team_standup", name: "Team standup", nameHi: "टीम स्टैंडअप", category: "Career", preferredVara: careerVara, preferredNakshatra: ["Hasta", "Pushya", "Ashwini"], avoidTithi: [4, 9], minTara: 0, karaka: ["Mercury"], blurb: "Mercury hora is enough for daily sync." },
  { key: "corporate_meeting", name: "Corporate meeting", nameHi: "कॉर्पोरेट मीटिंग", category: "Career", preferredVara: careerVara, preferredNakshatra: ["Hasta", "Pushya", "Revati"], avoidTithi: avoidLight, minTara: 2, karaka: ["Mercury", "Jupiter"], blurb: "Skip Rahu Kaal and Vishti Karana." },
  { key: "zoom_important", name: "Important video call", nameHi: "महत्वपूर्ण वीडियो कॉल", category: "Career", preferredVara: careerVara, preferredNakshatra: ["Hasta", "Pushya", "Revati"], avoidTithi: avoidLight, minTara: 2, karaka: ["Mercury"], blurb: "Mercury hora, avoid Tuesday for high-stakes calls." },
  { key: "presentation", name: "Client presentation", nameHi: "प्रस्तुति", category: "Career", preferredVara: careerVara, preferredNakshatra: ["Hasta", "Pushya", "Rohini"], avoidTithi: avoidRikta, minTara: 2, karaka: ["Mercury", "Sun"], blurb: "Hasta nakshatra favours speech and slides." },
  { key: "networking_event", name: "Networking event", nameHi: "नेटवर्किंग", category: "Career", preferredVara: ["Wednesday", "Friday", "Thursday"], preferredNakshatra: ["Swati", "Hasta", "Revati"], avoidTithi: avoidLight, minTara: 2, karaka: ["Venus", "Mercury"], blurb: "Soft and movable stars for meeting people." },
  { key: "linkedin_outreach", name: "Outreach campaign start", nameHi: "आउटरीच शुरू", category: "Career", preferredVara: ["Wednesday", "Friday"], preferredNakshatra: ["Hasta", "Ashwini"], avoidTithi: avoidLight, minTara: 0, karaka: ["Mercury"], blurb: "Swift nakshatras for sending volume." },

  { key: "business_deal", name: "Business deal / contract", nameHi: "व्यापारिक सौदा", category: "Business", preferredVara: financeVara, preferredNakshatra: ["Rohini", "Uttara Phalguni", "Uttara Ashadha", "Pushya"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Mercury", "Jupiter", "Venus"], blurb: "Fixed stars lock agreements." },
  { key: "partnership", name: "Partnership agreement", nameHi: "साझेदारी", category: "Business", preferredVara: ["Thursday", "Friday"], preferredNakshatra: ["Rohini", "Uttara Phalguni", "Revati"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Venus", "Jupiter"], blurb: "Venus + Jupiter; Chandra Bala should be strong." },
  { key: "new_venture", name: "New venture launch", nameHi: "नया उद्यम", category: "Business", preferredVara: ["Thursday", "Wednesday"], preferredNakshatra: ["Pushya", "Rohini", "Hasta"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Jupiter", "Sun"], blurb: "Pushya is classically used for beginnings." },
  { key: "vendor_meeting", name: "Vendor meeting", nameHi: "वेंडर मीटिंग", category: "Business", preferredVara: careerVara, preferredNakshatra: ["Hasta", "Anuradha"], avoidTithi: avoidLight, minTara: 2, karaka: ["Mercury"], blurb: "Anuradha supports fair terms." },
  { key: "pitch_investor", name: "Investor pitch", nameHi: "निवेशक पिच", category: "Business", preferredVara: ["Thursday", "Wednesday", "Friday"], preferredNakshatra: ["Pushya", "Hasta", "Rohini"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Jupiter", "Mercury"], blurb: "Jupiter weekday for capital conversations." },
  { key: "board_meeting", name: "Board meeting", nameHi: "बोर्ड मीटिंग", category: "Business", preferredVara: ["Thursday", "Wednesday"], preferredNakshatra: ["Uttara Phalguni", "Pushya"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Jupiter", "Sun"], blurb: "Avoid Rikta tithis for governance." },
  { key: "office_inauguration", name: "Office inauguration", nameHi: "कार्यालय शुभारंभ", category: "Business", preferredVara: ["Thursday", "Friday", "Wednesday"], preferredNakshatra: ["Rohini", "Uttara Phalguni", "Uttara Ashadha"], avoidTithi: avoidRikta, minTara: 6, karaka: ["Mars", "Jupiter"], blurb: "Fixed nakshatras for a lasting seat." },
  { key: "franchise_talks", name: "Franchise talks", nameHi: "फ्रैंचाइज़ी", category: "Business", preferredVara: financeVara, preferredNakshatra: ["Rohini", "Pushya"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Jupiter", "Mercury"], blurb: "Expansion under Guru hora." },
  { key: "export_order", name: "Export / import order", nameHi: "निर्यात आदेश", category: "Business", preferredVara: ["Wednesday", "Thursday"], preferredNakshatra: ["Punarvasu", "Hasta", "Pushya"], avoidTithi: avoidLight, minTara: 2, karaka: ["Mercury", "Moon"], blurb: "Movable stars suit cross-border work." },
  { key: "audit_start", name: "Audit kickoff", nameHi: "ऑडिट शुरू", category: "Business", preferredVara: ["Wednesday", "Thursday"], preferredNakshatra: ["Hasta", "Anuradha"], avoidTithi: avoidRikta, minTara: 2, karaka: ["Mercury", "Saturn"], blurb: "Saturn + Mercury for scrutiny." },
  { key: "rebrand", name: "Rebrand announcement", nameHi: "रिब्रांड", category: "Business", preferredVara: ["Friday", "Wednesday"], preferredNakshatra: ["Rohini", "Hasta", "Revati"], avoidTithi: avoidLight, minTara: 2, karaka: ["Venus", "Mercury"], blurb: "Venus weekday for image." },
  { key: "customer_meeting", name: "Customer meeting", nameHi: "ग्राहक मीटिंग", category: "Business", preferredVara: careerVara, preferredNakshatra: ["Hasta", "Rohini", "Pushya"], avoidTithi: avoidLight, minTara: 2, karaka: ["Mercury", "Venus"], blurb: "Soft speech nakshatras." },

  { key: "marketing_call", name: "Sales / marketing call", nameHi: "मार्केटिंग कॉल", category: "Marketing", preferredVara: ["Wednesday", "Friday", "Thursday"], preferredNakshatra: ["Hasta", "Chitra", "Swati", "Pushya"], avoidTithi: avoidLight, minTara: 2, karaka: ["Mercury", "Venus"], blurb: "Hasta and Swati for persuasion." },
  { key: "campaign_launch", name: "Campaign launch", nameHi: "कैम्पेन लॉन्च", category: "Marketing", preferredVara: ["Wednesday", "Friday"], preferredNakshatra: ["Hasta", "Pushya", "Ashwini"], avoidTithi: avoidRikta, minTara: 2, karaka: ["Mercury", "Sun"], blurb: "Swift stars for going live." },
  { key: "ad_spend", name: "Ad spend start", nameHi: "विज्ञापन खर्च", category: "Marketing", preferredVara: ["Wednesday", "Friday"], preferredNakshatra: ["Hasta", "Swati"], avoidTithi: avoidLight, minTara: 2, karaka: ["Mercury", "Venus"], blurb: "Avoid Rikta tithis for money out." },
  { key: "pr_release", name: "Press release", nameHi: "प्रेस रिलीज़", category: "Marketing", preferredVara: ["Wednesday", "Thursday"], preferredNakshatra: ["Hasta", "Pushya"], avoidTithi: avoidLight, minTara: 2, karaka: ["Mercury", "Sun"], blurb: "Mercury lord of news." },
  { key: "influencer_collab", name: "Influencer collab", nameHi: "इन्फ्लुएंसर सहयोग", category: "Marketing", preferredVara: ["Friday", "Wednesday"], preferredNakshatra: ["Rohini", "Revati", "Swati"], avoidTithi: avoidLight, minTara: 2, karaka: ["Venus", "Mercury"], blurb: "Venus for image partnerships." },
  { key: "content_shoot", name: "Content shoot", nameHi: "कंटेंट शूट", category: "Marketing", preferredVara: ["Friday", "Wednesday"], preferredNakshatra: ["Chitra", "Hasta", "Rohini"], avoidTithi: avoidLight, minTara: 2, karaka: ["Venus", "Sun"], blurb: "Chitra favours visual work." },

  { key: "financial_transaction", name: "Financial transfer", nameHi: "वित्तीय लेन-देन", category: "Finance", preferredVara: financeVara, preferredNakshatra: ["Rohini", "Pushya", "Hasta", "Uttara Phalguni"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Jupiter", "Venus", "Mercury"], blurb: "Skip Vishti and Rikta for money movement." },
  { key: "loan_application", name: "Loan application", nameHi: "लोन आवेदन", category: "Finance", preferredVara: ["Thursday", "Friday"], preferredNakshatra: ["Pushya", "Rohini", "Uttara Ashadha"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Jupiter", "Venus"], blurb: "Guru vara for credit." },
  { key: "investment", name: "Investment / SIP start", nameHi: "निवेश शुरू", category: "Finance", preferredVara: financeVara, preferredNakshatra: ["Rohini", "Pushya", "Uttara Phalguni"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Jupiter", "Mercury"], blurb: "Fixed stars for long holds." },
  { key: "tax_filing", name: "Tax filing", nameHi: "टैक्स फाइलिंग", category: "Finance", preferredVara: ["Wednesday", "Thursday"], preferredNakshatra: ["Hasta", "Anuradha"], avoidTithi: avoidLight, minTara: 2, karaka: ["Mercury", "Saturn"], blurb: "Mercury for paperwork, Saturn for compliance." },
  { key: "insurance", name: "Insurance purchase", nameHi: "बीमा", category: "Finance", preferredVara: ["Thursday", "Saturday"], preferredNakshatra: ["Pushya", "Anuradha"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Saturn", "Jupiter"], blurb: "Saturn karaka of protection." },
  { key: "open_account", name: "Open bank / demat account", nameHi: "खाता खोलना", category: "Finance", preferredVara: financeVara, preferredNakshatra: ["Pushya", "Rohini", "Hasta"], avoidTithi: avoidRikta, minTara: 2, karaka: ["Mercury", "Jupiter"], blurb: "Pushya is a classic banking muhurat." },
  { key: "pay_debt", name: "Clear a debt", nameHi: "कर्ज चुकाना", category: "Finance", preferredVara: ["Thursday", "Saturday"], preferredNakshatra: ["Anuradha", "Uttara Ashadha"], avoidTithi: avoidLight, minTara: 2, karaka: ["Saturn", "Jupiter"], blurb: "Saturn weekday can close obligations." },
  { key: "fundraising_close", name: "Fundraising close", nameHi: "फंडिंग बंद", category: "Finance", preferredVara: ["Thursday", "Friday"], preferredNakshatra: ["Rohini", "Pushya", "Uttara Phalguni"], avoidTithi: avoidRikta, minTara: 6, karaka: ["Jupiter", "Venus"], blurb: "High Tara minimum for capital close." },
  { key: "budget_planning", name: "Annual budget planning", nameHi: "बजट योजना", category: "Finance", preferredVara: ["Thursday", "Wednesday"], preferredNakshatra: ["Hasta", "Pushya"], avoidTithi: avoidLight, minTara: 2, karaka: ["Mercury", "Jupiter"], blurb: "Hasta for counting and plans." },
  { key: "crypto_trade", name: "High-risk trade", nameHi: "जोखिम भरा ट्रेड", category: "Finance", preferredVara: ["Wednesday", "Thursday"], preferredNakshatra: ["Hasta", "Swati"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Mercury"], blurb: "Never on Vishti; Tara should be shubh." },

  { key: "doctor_appointment", name: "Doctor appointment", nameHi: "डॉक्टर अपॉइंटमेंट", category: "Health", preferredVara: relVara, preferredNakshatra: ["Ashwini", "Hasta", "Pushya", "Revati"], avoidTithi: [4, 9, 14, 30], minTara: 2, karaka: ["Moon", "Mercury", "Jupiter"], blurb: "Ashwini is the physician star." },
  { key: "surgery", name: "Surgery", nameHi: "सर्जरी", category: "Health", preferredVara: ["Monday", "Wednesday", "Thursday"], preferredNakshatra: ["Ashwini", "Hasta", "Pushya"], avoidTithi: avoidRikta, minTara: 6, karaka: ["Mars", "Mercury"], blurb: "Avoid fierce nakshatras unless the surgeon advises otherwise." },
  { key: "lab_test", name: "Lab test", nameHi: "लैब टेस्ट", category: "Health", preferredVara: ["Monday", "Wednesday"], preferredNakshatra: ["Hasta", "Ashwini"], avoidTithi: avoidLight, minTara: 0, karaka: ["Mercury", "Moon"], blurb: "Hasta for diagnostics." },
  { key: "start_medication", name: "Start new medication", nameHi: "नई दवा शुरू", category: "Health", preferredVara: ["Monday", "Thursday"], preferredNakshatra: ["Ashwini", "Pushya", "Revati"], avoidTithi: avoidLight, minTara: 2, karaka: ["Moon", "Jupiter"], blurb: "Pushya is auspicious for remedies." },
  { key: "therapy_session", name: "Therapy / counselling", nameHi: "थेरेपी", category: "Health", preferredVara: ["Monday", "Wednesday", "Friday"], preferredNakshatra: ["Revati", "Rohini", "Pushya"], avoidTithi: [4, 9], minTara: 2, karaka: ["Moon", "Venus"], blurb: "Soft nakshatras, strong Chandra Bala." },
  { key: "fitness_start", name: "Start fitness plan", nameHi: "फिटनेस शुरू", category: "Health", preferredVara: ["Tuesday", "Thursday", "Sunday"], preferredNakshatra: ["Ashwini", "Hasta", "Pushya"], avoidTithi: avoidLight, minTara: 2, karaka: ["Mars", "Sun"], blurb: "Mars hora for physical starts." },
  { key: "dental", name: "Dental procedure", nameHi: "दंत चिकित्सा", category: "Health", preferredVara: ["Monday", "Wednesday"], preferredNakshatra: ["Ashwini", "Hasta"], avoidTithi: avoidRikta, minTara: 2, karaka: ["Mercury", "Mars"], blurb: "Avoid Purnima/Amavasya if possible." },
  { key: "vaccination", name: "Vaccination", nameHi: "टीकाकरण", category: "Health", preferredVara: ["Monday", "Wednesday", "Thursday"], preferredNakshatra: ["Ashwini", "Pushya"], avoidTithi: avoidLight, minTara: 2, karaka: ["Moon", "Jupiter"], blurb: "Ashwini + Pushya preferred." },

  { key: "travel_booking", name: "Book tickets", nameHi: "टिकट बुकिंग", category: "Travel", preferredVara: ["Wednesday", "Thursday", "Friday", "Monday"], preferredNakshatra: ["Hasta", "Pushya", "Ashwini", "Punarvasu"], avoidTithi: avoidLight, minTara: 2, karaka: ["Moon", "Mercury"], blurb: "Booking can sit on a milder window than the actual start." },
  { key: "start_journey", name: "Start journey", nameHi: "यात्रा शुरू", category: "Travel", preferredVara: relVara, preferredNakshatra: ["Ashwini", "Punarvasu", "Hasta", "Pushya", "Anuradha"], avoidTithi: [4, 9, 14, 30], minTara: 2, karaka: ["Moon", "Mercury"], blurb: "Avoid Rahu Kaal at departure." },
  { key: "visa_application", name: "Visa application", nameHi: "वीज़ा आवेदन", category: "Travel", preferredVara: ["Wednesday", "Thursday"], preferredNakshatra: ["Hasta", "Punarvasu", "Pushya"], avoidTithi: avoidRikta, minTara: 2, karaka: ["Mercury", "Jupiter"], blurb: "Mercury for documents, Jupiter for grace." },
  { key: "hotel_checkin", name: "Hotel check-in", nameHi: "होटल चेक-इन", category: "Travel", preferredVara: relVara, preferredNakshatra: ["Rohini", "Pushya", "Revati"], avoidTithi: [4, 9], minTara: 0, karaka: ["Moon", "Venus"], blurb: "Soft stars for settling in." },
  { key: "relocation", name: "Relocation / moving city", nameHi: "शहर बदलना", category: "Travel", preferredVara: ["Wednesday", "Thursday", "Friday"], preferredNakshatra: ["Punarvasu", "Rohini", "Uttara Ashadha"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Moon", "Mars"], blurb: "Punarvasu is the return-and-settle star." },
  { key: "pilgrimage", name: "Pilgrimage", nameHi: "तीर्थ यात्रा", category: "Travel", preferredVara: ["Thursday", "Monday"], preferredNakshatra: ["Pushya", "Revati", "Uttara Bhadrapada"], avoidTithi: [], minTara: 2, karaka: ["Jupiter", "Moon"], blurb: "Thursday and Pushya are classic." },
  { key: "road_trip", name: "Road trip start", nameHi: "रोड ट्रिप", category: "Travel", preferredVara: ["Monday", "Wednesday", "Thursday"], preferredNakshatra: ["Ashwini", "Punarvasu", "Hasta"], avoidTithi: avoidLight, minTara: 2, karaka: ["Moon", "Mars"], blurb: "Ashwini for swift movement." },
  { key: "foreign_travel", name: "International travel", nameHi: "विदेश यात्रा", category: "Travel", preferredVara: ["Wednesday", "Thursday"], preferredNakshatra: ["Punarvasu", "Swati", "Shravana"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Moon", "Mercury", "Rahu"], blurb: "Movable nakshatras for crossing water." },

  { key: "vehicle_purchase", name: "Vehicle purchase", nameHi: "गाड़ी खरीदना", category: "Purchase", preferredVara: careerVara, preferredNakshatra: ["Rohini", "Uttara Phalguni", "Hasta", "Anuradha"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Venus", "Mars", "Mercury"], blurb: "Rohini is a standard vehicle muhurat." },
  { key: "electronics", name: "Electronics purchase", nameHi: "इलेक्ट्रॉनिक्स", category: "Purchase", preferredVara: ["Wednesday", "Friday"], preferredNakshatra: ["Hasta", "Chitra", "Pushya"], avoidTithi: avoidLight, minTara: 2, karaka: ["Mercury", "Venus"], blurb: "Mercury for devices." },
  { key: "jewellery", name: "Jewellery purchase", nameHi: "आभूषण", category: "Purchase", preferredVara: ["Friday", "Monday"], preferredNakshatra: ["Rohini", "Revati", "Pushya"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Venus", "Moon"], blurb: "Friday + Rohini." },
  { key: "furniture", name: "Furniture / appliances", nameHi: "फर्नीचर", category: "Purchase", preferredVara: ["Friday", "Wednesday"], preferredNakshatra: ["Rohini", "Uttara Phalguni"], avoidTithi: avoidLight, minTara: 2, karaka: ["Venus", "Mars"], blurb: "Fixed stars for items that stay." },
  { key: "groceries_bulk", name: "Bulk household stock", nameHi: "थोक खरीदारी", category: "Purchase", preferredVara: ["Monday", "Friday"], preferredNakshatra: ["Rohini", "Pushya"], avoidTithi: [4, 9], minTara: 0, karaka: ["Moon", "Venus"], blurb: "Rohini rules growth and stores." },
  { key: "gift_buy", name: "Buy a significant gift", nameHi: "उपहार", category: "Purchase", preferredVara: ["Friday", "Wednesday"], preferredNakshatra: ["Rohini", "Revati", "Hasta"], avoidTithi: avoidLight, minTara: 2, karaka: ["Venus"], blurb: "Venus hora." },
  { key: "art_collect", name: "Art / collectible buy", nameHi: "कला खरीद", category: "Purchase", preferredVara: ["Friday", "Thursday"], preferredNakshatra: ["Chitra", "Rohini", "Revati"], avoidTithi: avoidLight, minTara: 4, karaka: ["Venus", "Mercury"], blurb: "Chitra for form and beauty." },
  { key: "subscription_annual", name: "Annual subscription", nameHi: "वार्षिक सदस्यता", category: "Purchase", preferredVara: ["Thursday", "Wednesday"], preferredNakshatra: ["Pushya", "Hasta"], avoidTithi: avoidLight, minTara: 2, karaka: ["Jupiter", "Mercury"], blurb: "Thursday for recurring value." },

  { key: "property_purchase", name: "Property purchase", nameHi: "प्रॉपर्टी खरीद", category: "Real Estate", preferredVara: ["Thursday", "Friday", "Monday"], preferredNakshatra: ["Rohini", "Uttara Phalguni", "Uttara Ashadha", "Uttara Bhadrapada"], avoidTithi: avoidRikta, minTara: 6, karaka: ["Mars", "Venus", "Jupiter", "Saturn"], blurb: "Fixed Uttara stars for land." },
  { key: "property_registration", name: "Property registration", nameHi: "रजिस्ट्री", category: "Real Estate", preferredVara: ["Thursday", "Friday", "Wednesday"], preferredNakshatra: ["Rohini", "Uttara Phalguni", "Uttara Ashadha"], avoidTithi: avoidRikta, minTara: 6, karaka: ["Mars", "Mercury"], blurb: "High Tara bar; skip Vishti." },
  { key: "housewarming", name: "Griha pravesh", nameHi: "गृह प्रवेश", category: "Real Estate", preferredVara: ["Thursday", "Friday", "Monday", "Wednesday"], preferredNakshatra: ["Rohini", "Uttara Phalguni", "Uttara Ashadha", "Revati"], avoidTithi: avoidRikta, minTara: 6, karaka: ["Mars", "Venus", "Jupiter"], blurb: "Classical griha pravesh stars." },
  { key: "rent_house", name: "Sign a rental", nameHi: "किराया समझौता", category: "Real Estate", preferredVara: ["Wednesday", "Thursday", "Friday"], preferredNakshatra: ["Rohini", "Punarvasu", "Pushya"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Moon", "Venus"], blurb: "Punarvasu for temporary dwellings." },
  { key: "home_renovation", name: "Start renovation", nameHi: "नवीनीकरण", category: "Real Estate", preferredVara: ["Wednesday", "Thursday", "Friday"], preferredNakshatra: ["Rohini", "Uttara Phalguni", "Hasta"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Mars", "Venus"], blurb: "Avoid fierce nakshatras for breaking work if possible." },
  { key: "vastu_consult", name: "Vastu consultation", nameHi: "वास्तु परामर्श", category: "Real Estate", preferredVara: ["Thursday", "Wednesday"], preferredNakshatra: ["Pushya", "Hasta"], avoidTithi: avoidLight, minTara: 2, karaka: ["Jupiter", "Mercury"], blurb: "Guru vara." },

  { key: "dating", name: "First date", nameHi: "पहली मुलाकात", category: "Relationship", preferredVara: ["Friday", "Monday", "Wednesday"], preferredNakshatra: ["Rohini", "Hasta", "Swati", "Revati"], avoidTithi: avoidLight, minTara: 2, karaka: ["Venus", "Moon"], blurb: "Friday + Rohini or Revati." },
  { key: "engagement", name: "Fix engagement", nameHi: "सगाई तय करना", category: "Relationship", preferredVara: relVara, preferredNakshatra: ["Rohini", "Uttara Phalguni", "Hasta", "Swati", "Anuradha"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Venus", "Moon", "Jupiter"], blurb: "Avoid Rikta and Vishti." },
  { key: "marriage", name: "Marriage", nameHi: "विवाह", category: "Relationship", preferredVara: relVara, preferredNakshatra: ["Rohini", "Uttara Phalguni", "Uttara Ashadha", "Uttara Bhadrapada", "Revati"], avoidTithi: avoidRikta, minTara: 6, karaka: ["Venus", "Jupiter", "Moon"], blurb: "Full lagna shuddhi still needed with a pandit for the ceremony." },
  { key: "proposal", name: "Propose", nameHi: "प्रपोज़", category: "Relationship", preferredVara: ["Friday", "Monday"], preferredNakshatra: ["Rohini", "Revati", "Uttara Phalguni"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Venus", "Moon"], blurb: "Venus hora, strong Chandra Bala." },
  { key: "reconcile", name: "Reconcile after a fight", nameHi: "सुलह", category: "Relationship", preferredVara: ["Friday", "Monday", "Thursday"], preferredNakshatra: ["Revati", "Rohini", "Anuradha"], avoidTithi: [4, 9, 14], minTara: 2, karaka: ["Venus", "Moon", "Jupiter"], blurb: "Soft stars, not Ugra." },
  { key: "meet_parents", name: "Meet the family", nameHi: "परिवार से मिलना", category: "Relationship", preferredVara: relVara, preferredNakshatra: ["Rohini", "Pushya", "Revati"], avoidTithi: avoidLight, minTara: 2, karaka: ["Moon", "Venus", "Jupiter"], blurb: "Pushya for family blessing." },
  { key: "anniversary", name: "Anniversary plan", nameHi: "वर्षगांठ", category: "Relationship", preferredVara: ["Friday", "Monday"], preferredNakshatra: ["Rohini", "Revati"], avoidTithi: avoidLight, minTara: 2, karaka: ["Venus", "Moon"], blurb: "Friday evening Venus hora." },
  { key: "breakup_talk", name: "Difficult relationship talk", nameHi: "कठिन बातचीत", category: "Relationship", preferredVara: ["Wednesday", "Thursday"], preferredNakshatra: ["Hasta", "Anuradha"], avoidTithi: [8, 9, 14], minTara: 2, karaka: ["Mercury", "Saturn"], blurb: "Clarity over romance; skip fierce tithis." },

  { key: "child_birth_planning", name: "Plan birth timing", nameHi: "जन्म समय", category: "Family", preferredVara: relVara, preferredNakshatra: ["Pushya", "Rohini", "Hasta", "Revati", "Ashwini"], avoidTithi: avoidRikta, minTara: 6, karaka: ["Jupiter", "Moon", "Venus"], blurb: "Medical necessity always overrides muhurat." },
  { key: "naming_ceremony", name: "Namakarana", nameHi: "नामकरण", category: "Family", preferredVara: relVara, preferredNakshatra: ["Pushya", "Hasta", "Rohini", "Revati"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Mercury", "Jupiter", "Moon"], blurb: "Mercury for the name itself." },
  { key: "annaprashana", name: "First feeding", nameHi: "अन्नप्राशन", category: "Family", preferredVara: ["Monday", "Thursday", "Friday"], preferredNakshatra: ["Pushya", "Rohini", "Revati"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Moon", "Jupiter"], blurb: "Pushya is traditional." },
  { key: "school_admission", name: "School admission", nameHi: "स्कूल दाखिला", category: "Family", preferredVara: careerVara, preferredNakshatra: ["Hasta", "Pushya", "Revati"], avoidTithi: avoidLight, minTara: 2, karaka: ["Mercury", "Jupiter"], blurb: "Mercury + Jupiter." },
  { key: "birthday_party", name: "Child birthday", nameHi: "जन्मदिन", category: "Family", preferredVara: ["Friday", "Monday", "Thursday"], preferredNakshatra: ["Rohini", "Pushya", "Revati"], avoidTithi: [4, 9, 14], minTara: 2, karaka: ["Moon", "Venus"], blurb: "Joy over strictness; still skip Vishti." },
  { key: "family_gathering", name: "Family gathering", nameHi: "पारिवारिक जमावड़ा", category: "Family", preferredVara: ["Thursday", "Friday", "Monday"], preferredNakshatra: ["Rohini", "Pushya", "Revati"], avoidTithi: [4, 9], minTara: 0, karaka: ["Moon", "Jupiter"], blurb: "Thursday for elders." },
  { key: "elder_care", name: "Elder-care decision", nameHi: "बुजुर्ग देखभाल", category: "Family", preferredVara: ["Thursday", "Monday"], preferredNakshatra: ["Pushya", "Anuradha", "Revati"], avoidTithi: avoidLight, minTara: 2, karaka: ["Jupiter", "Saturn", "Moon"], blurb: "Saturn + Jupiter for duty." },
  { key: "pet_adoption", name: "Adopt a pet", nameHi: "पालतू लाना", category: "Family", preferredVara: ["Monday", "Friday"], preferredNakshatra: ["Rohini", "Revati", "Pushya"], avoidTithi: avoidLight, minTara: 2, karaka: ["Moon", "Venus"], blurb: "Moon for living beings." },

  { key: "education_start", name: "Start a course", nameHi: "कोर्स शुरू", category: "Education", preferredVara: careerVara, preferredNakshatra: ["Hasta", "Pushya", "Ashwini", "Revati"], avoidTithi: avoidLight, minTara: 2, karaka: ["Mercury", "Jupiter"], blurb: "Vidya starts on Mercury/Jupiter days." },
  { key: "exam", name: "Sit an exam", nameHi: "परीक्षा", category: "Education", preferredVara: careerVara, preferredNakshatra: ["Hasta", "Pushya", "Revati", "Ashwini"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Mercury", "Jupiter"], blurb: "Hasta is the hand of skill." },
  { key: "thesis_submit", name: "Submit thesis / paper", nameHi: "पेपर जमा", category: "Education", preferredVara: ["Wednesday", "Thursday"], preferredNakshatra: ["Hasta", "Pushya"], avoidTithi: avoidLight, minTara: 2, karaka: ["Mercury", "Jupiter"], blurb: "Mercury hora." },
  { key: "skill_workshop", name: "Workshop / training", nameHi: "प्रशिक्षण", category: "Education", preferredVara: careerVara, preferredNakshatra: ["Hasta", "Pushya", "Ashwini"], avoidTithi: avoidLight, minTara: 2, karaka: ["Mercury"], blurb: "Swift stars for learning bursts." },
  { key: "language_start", name: "Start a language", nameHi: "भाषा शुरू", category: "Education", preferredVara: ["Wednesday", "Friday"], preferredNakshatra: ["Hasta", "Revati", "Punarvasu"], avoidTithi: avoidLight, minTara: 2, karaka: ["Mercury", "Venus"], blurb: "Mercury is speech." },
  { key: "coaching_enroll", name: "Enroll in coaching", nameHi: "कोचिंग दाखिला", category: "Education", preferredVara: careerVara, preferredNakshatra: ["Hasta", "Pushya"], avoidTithi: avoidLight, minTara: 2, karaka: ["Mercury", "Jupiter"], blurb: "Same as vidyarambha." },

  { key: "court_case", name: "Court hearing", nameHi: "कोर्ट केस", category: "Legal", preferredVara: ["Thursday", "Friday", "Wednesday"], preferredNakshatra: ["Pushya", "Hasta", "Anuradha", "Uttara Ashadha"], avoidTithi: avoidRikta, minTara: 6, karaka: ["Jupiter", "Saturn", "Mercury"], blurb: "Jupiter for dharma, Saturn for process." },
  { key: "affidavit", name: "Sign affidavit", nameHi: "शपथ पत्र", category: "Legal", preferredVara: ["Wednesday", "Thursday"], preferredNakshatra: ["Hasta", "Anuradha"], avoidTithi: avoidRikta, minTara: 2, karaka: ["Mercury", "Saturn"], blurb: "Mercury for writing, skip Vishti." },
  { key: "will_write", name: "Write a will", nameHi: "वसीयत", category: "Legal", preferredVara: ["Thursday", "Saturday"], preferredNakshatra: ["Uttara Ashadha", "Anuradha", "Pushya"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Saturn", "Jupiter"], blurb: "Saturn karaka of endings done well." },
  { key: "legal_notice", name: "Send legal notice", nameHi: "लीगल नोटिस", category: "Legal", preferredVara: ["Wednesday", "Thursday"], preferredNakshatra: ["Hasta", "Jyeshtha", "Anuradha"], avoidTithi: avoidLight, minTara: 4, karaka: ["Mercury", "Mars"], blurb: "Not on Vishti." },

  { key: "website_launch", name: "Website / app launch", nameHi: "ऐप लॉन्च", category: "Technology", preferredVara: careerVara, preferredNakshatra: ["Hasta", "Pushya", "Rohini"], avoidTithi: [4, 9, 14, 30], minTara: 2, karaka: ["Mercury", "Jupiter"], blurb: "Mercury hora, Pushya if you can wait." },
  { key: "deploy_prod", name: "Production deploy", nameHi: "प्रोडक्शन डिप्लॉय", category: "Technology", preferredVara: ["Wednesday", "Thursday"], preferredNakshatra: ["Hasta", "Pushya", "Ashwini"], avoidTithi: avoidLight, minTara: 2, karaka: ["Mercury"], blurb: "Avoid Rahu Kaal for go-live." },
  { key: "buy_domain", name: "Buy domain / brand name", nameHi: "डोमेन खरीद", category: "Technology", preferredVara: ["Wednesday", "Friday"], preferredNakshatra: ["Hasta", "Rohini"], avoidTithi: avoidLight, minTara: 2, karaka: ["Mercury", "Venus"], blurb: "Name = Mercury + Venus." },
  { key: "data_migration", name: "Data migration", nameHi: "डेटा माइग्रेशन", category: "Technology", preferredVara: ["Wednesday", "Thursday"], preferredNakshatra: ["Hasta", "Punarvasu"], avoidTithi: avoidLight, minTara: 2, karaka: ["Mercury", "Saturn"], blurb: "Punarvasu for moving and restoring." },

  { key: "daily_start", name: "Start an important day", nameHi: "दिन की शुरुआत", category: "Daily", preferredVara: relVara, preferredNakshatra: ["Hasta", "Pushya", "Ashwini"], avoidTithi: avoidLight, minTara: 0, karaka: ["Sun", "Mercury"], blurb: "Abhijit muhurat is a safe universal window." },
  { key: "deep_work", name: "Deep work block", nameHi: "गहन कार्य", category: "Daily", preferredVara: ["Wednesday", "Thursday", "Saturday"], preferredNakshatra: ["Hasta", "Anuradha"], avoidTithi: [4, 9], minTara: 0, karaka: ["Mercury", "Saturn"], blurb: "Saturn hora for focus." },
  { key: "inbox_zero", name: "Difficult emails", nameHi: "कठिन ईमेल", category: "Daily", preferredVara: ["Wednesday", "Thursday"], preferredNakshatra: ["Hasta", "Pushya"], avoidTithi: [4, 9, 14], minTara: 0, karaka: ["Mercury"], blurb: "Mercury hora; skip Vishti." },
  { key: "habit_start", name: "Start a habit", nameHi: "आदत शुरू", category: "Daily", preferredVara: ["Thursday", "Monday", "Wednesday"], preferredNakshatra: ["Rohini", "Pushya", "Uttara Ashadha"], avoidTithi: avoidLight, minTara: 2, karaka: ["Saturn", "Moon"], blurb: "Fixed stars help habits stick." },
  { key: "sleep_early", name: "Reset sleep schedule", nameHi: "नींद सुधार", category: "Daily", preferredVara: ["Monday", "Thursday"], preferredNakshatra: ["Revati", "Rohini"], avoidTithi: [], minTara: 0, karaka: ["Moon"], blurb: "Moon hora in the evening." },
  { key: "cook_feast", name: "Cook for guests", nameHi: "मेहमानों के लिए पकाना", category: "Daily", preferredVara: ["Friday", "Monday", "Thursday"], preferredNakshatra: ["Rohini", "Pushya"], avoidTithi: [4, 9], minTara: 0, karaka: ["Venus", "Moon"], blurb: "Rohini rules the kitchen." },
  { key: "declutter", name: "Declutter / donate", nameHi: "साफ़-सफाई", category: "Daily", preferredVara: ["Saturday", "Wednesday"], preferredNakshatra: ["Hasta", "Ardra"], avoidTithi: [], minTara: 0, karaka: ["Saturn"], blurb: "Saturday is useful for letting go." },
  { key: "journal", name: "Journal / planning night", nameHi: "जर्नल", category: "Daily", preferredVara: ["Monday", "Wednesday"], preferredNakshatra: ["Hasta", "Revati"], avoidTithi: [], minTara: 0, karaka: ["Mercury", "Moon"], blurb: "Mercury + Moon." },

  { key: "puja", name: "Puja / havan", nameHi: "पूजा", category: "Spiritual", preferredVara: ["Monday", "Thursday", "Friday"], preferredNakshatra: ["Pushya", "Rohini", "Uttara Bhadrapada", "Revati"], avoidTithi: [], minTara: 0, karaka: ["Jupiter", "Moon"], blurb: "Most tithis can host worship; prefer Pushya." },
  { key: "meditation_start", name: "Begin a sadhana", nameHi: "साधना शुरू", category: "Spiritual", preferredVara: ["Thursday", "Monday"], preferredNakshatra: ["Pushya", "Revati", "Uttara Bhadrapada"], avoidTithi: [], minTara: 2, karaka: ["Jupiter", "Ketu"], blurb: "Brahma muhurta still trumps weekday." },
  { key: "mantra_diksha", name: "Mantra initiation", nameHi: "मंत्र दीक्षा", category: "Spiritual", preferredVara: ["Thursday", "Monday"], preferredNakshatra: ["Pushya", "Rohini", "Revati"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Jupiter", "Moon"], blurb: "Guru vara." },
  { key: "temple_visit", name: "Temple visit", nameHi: "मंदिर जाना", category: "Spiritual", preferredVara: ["Thursday", "Monday", "Friday"], preferredNakshatra: ["Pushya", "Revati"], avoidTithi: [], minTara: 0, karaka: ["Jupiter"], blurb: "Any shubh hora works." },

  { key: "send_resume", name: "Send a resume", nameHi: "रेज़्यूमे भेजना", category: "Career", preferredVara: careerVara, preferredNakshatra: ["Hasta", "Pushya", "Ashwini"], avoidTithi: avoidLight, minTara: 2, karaka: ["Mercury", "Sun"], blurb: "Swift stars for a first impression." },
  { key: "client_call", name: "Call a client for payment", nameHi: "क्लाइंट को कॉल", category: "Finance", preferredVara: financeVara, preferredNakshatra: ["Hasta", "Pushya", "Rohini"], avoidTithi: avoidRikta, minTara: 2, karaka: ["Mercury", "Jupiter", "Venus"], blurb: "Guru or Shukra hora for asking money." },
  { key: "file_case", name: "File a court case", nameHi: "केस फाइल करना", category: "Legal", preferredVara: ["Thursday", "Wednesday", "Friday"], preferredNakshatra: ["Pushya", "Hasta", "Anuradha", "Uttara Ashadha"], avoidTithi: avoidRikta, minTara: 6, karaka: ["Jupiter", "Saturn", "Mercury"], blurb: "Dharma tithi plus Guru mahadasha is ideal." },
  { key: "election_nomination", name: "Election nomination filing", nameHi: "नामांकन पत्र", category: "Civic", preferredVara: ["Thursday", "Wednesday", "Sunday"], preferredNakshatra: ["Pushya", "Hasta", "Ashwini", "Uttara Phalguni"], avoidTithi: avoidRikta, minTara: 6, karaka: ["Sun", "Jupiter", "Mercury"], blurb: "Sun for office, Jupiter for public trust." },
  { key: "minister_entry", name: "Minister / office entry", nameHi: "कार्यालय प्रवेश", category: "Civic", preferredVara: ["Thursday", "Sunday", "Wednesday"], preferredNakshatra: ["Pushya", "Rohini", "Uttara Phalguni", "Uttara Ashadha"], avoidTithi: avoidRikta, minTara: 6, karaka: ["Sun", "Jupiter", "Mars"], blurb: "Fixed stars lock a public seat." },
  { key: "oath_ceremony", name: "Oath of office", nameHi: "शपथ ग्रहण", category: "Civic", preferredVara: ["Thursday", "Sunday"], preferredNakshatra: ["Pushya", "Uttara Phalguni", "Rohini"], avoidTithi: avoidRikta, minTara: 6, karaka: ["Sun", "Jupiter"], blurb: "Amrit or Sarvartha Siddhi preferred." },
  { key: "campaign_speech", name: "Public address", nameHi: "सार्वजनिक भाषण", category: "Civic", preferredVara: ["Wednesday", "Thursday", "Sunday"], preferredNakshatra: ["Hasta", "Pushya", "Ashwini"], avoidTithi: avoidLight, minTara: 4, karaka: ["Mercury", "Sun"], blurb: "Hasta for speech; skip Vishti." },
  { key: "company_incorporation", name: "Company incorporation", nameHi: "कंपनी पंजीकरण", category: "Business", preferredVara: ["Thursday", "Wednesday", "Friday"], preferredNakshatra: ["Rohini", "Pushya", "Uttara Phalguni", "Uttara Ashadha"], avoidTithi: avoidRikta, minTara: 6, karaka: ["Jupiter", "Mercury", "Sun"], blurb: "Fixed nakshatra plus Guru hora." },
  { key: "movie_launch", name: "Film / show launch", nameHi: "फिल्म लॉन्च", category: "Media", preferredVara: ["Friday", "Thursday", "Wednesday"], preferredNakshatra: ["Rohini", "Hasta", "Chitra", "Pushya", "Revati"], avoidTithi: avoidRikta, minTara: 6, karaka: ["Venus", "Mercury", "Sun"], blurb: "Shukra for image, Budh for the public." },
  { key: "music_release", name: "Music or book release", nameHi: "रिलीज़", category: "Media", preferredVara: ["Friday", "Wednesday", "Thursday"], preferredNakshatra: ["Rohini", "Revati", "Hasta", "Pushya"], avoidTithi: avoidRikta, minTara: 4, karaka: ["Venus", "Mercury"], blurb: "Venus weekday, avoid Rikta." },
  { key: "product_launch", name: "Product launch", nameHi: "प्रोडक्ट लॉन्च", category: "Business", preferredVara: ["Thursday", "Wednesday", "Friday"], preferredNakshatra: ["Pushya", "Rohini", "Hasta"], avoidTithi: avoidRikta, minTara: 6, karaka: ["Jupiter", "Mercury", "Venus"], blurb: "Pushya or Sarvartha Siddhi for go-live." },
  { key: "ipo_listing", name: "IPO / listing", nameHi: "आईपीओ", category: "Finance", preferredVara: ["Thursday", "Friday", "Wednesday"], preferredNakshatra: ["Rohini", "Pushya", "Uttara Phalguni"], avoidTithi: avoidRikta, minTara: 6, karaka: ["Jupiter", "Venus", "Mercury"], blurb: "Capital close — high Tara bar." },
  { key: "engagement_ceremony", name: "Engagement ceremony", nameHi: "सगाई समारोह", category: "Relationship", preferredVara: relVara, preferredNakshatra: ["Rohini", "Uttara Phalguni", "Hasta", "Revati"], avoidTithi: avoidRikta, minTara: 6, karaka: ["Venus", "Jupiter", "Moon"], blurb: "Ceremony needs a golden window, not just a talk." },
  { key: "vivah_muhurat", name: "Vivah muhurat", nameHi: "विवाह मुहूर्त", category: "Relationship", preferredVara: relVara, preferredNakshatra: ["Rohini", "Uttara Phalguni", "Uttara Ashadha", "Uttara Bhadrapada", "Revati", "Swati"], avoidTithi: avoidRikta, minTara: 6, karaka: ["Venus", "Jupiter", "Moon"], blurb: "Lagna shuddhi still belongs with a pandit; this scores the window." },
  { key: "dating_meet", name: "Dating / courtship meet", nameHi: "डेटिंग", category: "Relationship", preferredVara: ["Friday", "Monday", "Wednesday"], preferredNakshatra: ["Rohini", "Hasta", "Swati", "Revati"], avoidTithi: avoidLight, minTara: 2, karaka: ["Venus", "Moon"], blurb: "Friday plus Rohini or Revati." },
];

const MAJOR_KEYS = new Set([
  "job_joining",
  "salary_negotiation",
  "business_deal",
  "partnership",
  "new_venture",
  "office_inauguration",
  "fundraising_close",
  "surgery",
  "property_purchase",
  "property_registration",
  "housewarming",
  "marriage",
  "engagement",
  "child_birth_planning",
  "naming_ceremony",
  "court_case",
  "will_write",
  "file_case",
  "election_nomination",
  "minister_entry",
  "oath_ceremony",
  "company_incorporation",
  "movie_launch",
  "product_launch",
  "ipo_listing",
  "engagement_ceremony",
  "vivah_muhurat",
  "relocation",
]);

const CAT_PURUSHARTHA: Record<string, Purushartha> = {
  Career: "artha",
  Business: "artha",
  Marketing: "artha",
  Finance: "artha",
  Health: "dharma",
  Travel: "kama",
  Purchase: "artha",
  "Real Estate": "artha",
  Relationship: "kama",
  Family: "dharma",
  Education: "dharma",
  Legal: "dharma",
  Civic: "dharma",
  Media: "kama",
  Technology: "artha",
  Daily: "artha",
  Spiritual: "moksha",
};

const CAT_TATVA: Record<string, Tatva> = {
  Career: "vayu",
  Business: "prithvi",
  Marketing: "vayu",
  Finance: "prithvi",
  Health: "jala",
  Travel: "vayu",
  Purchase: "prithvi",
  "Real Estate": "prithvi",
  Relationship: "jala",
  Family: "jala",
  Education: "vayu",
  Legal: "agni",
  Civic: "agni",
  Media: "vayu",
  Technology: "vayu",
  Daily: "vayu",
  Spiritual: "jala",
};

const CAT_GUNA: Record<string, Guna> = {
  Career: "rajas",
  Business: "rajas",
  Marketing: "rajas",
  Finance: "sattva",
  Health: "sattva",
  Travel: "rajas",
  Purchase: "rajas",
  "Real Estate": "sattva",
  Relationship: "rajas",
  Family: "sattva",
  Education: "sattva",
  Legal: "sattva",
  Civic: "sattva",
  Media: "rajas",
  Technology: "rajas",
  Daily: "rajas",
  Spiritual: "sattva",
};

function finalize(seed: Seed): Activity {
  const major = MAJOR_KEYS.has(seed.key) || seed.minTara >= 6;
  return {
    ...seed,
    tier: major ? "major" : "daily",
    purushartha: CAT_PURUSHARTHA[seed.category] ?? "artha",
    tatva: CAT_TATVA[seed.category] ?? "vayu",
    guna: CAT_GUNA[seed.category] ?? "rajas",
    creditCost: major ? 5 : 1,
  };
}

export const ACTIVITIES: Activity[] = [...SEED.map(finalize), ...(CATALOG as Activity[])];

export function getActivity(key: string): Activity | undefined {
  return ACTIVITIES.find((a) => a.key === key);
}

export function activitiesByCategory(): Record<string, Activity[]> {
  const map: Record<string, Activity[]> = {};
  for (const a of ACTIVITIES) {
    (map[a.category] ??= []).push(a);
  }
  return map;
}

